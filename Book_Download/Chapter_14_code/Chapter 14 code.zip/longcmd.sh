#!/bin/bash
#trap 'echo "`date`: ouch!"' 15

echo "`date`: Starting"
sleep 20
echo "`date`: Stage Two"
sleep 20
echo "`date`: Finished"
