#!/bin/sh

. ./lib

func1

echo "I also get func2 for free..."
func2
