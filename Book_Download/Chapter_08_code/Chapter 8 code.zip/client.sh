#!/bin/bash

. ./network

shownetwork $@
