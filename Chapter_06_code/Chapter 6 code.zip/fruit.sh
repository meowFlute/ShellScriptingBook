#!/bin/bash
for fruit in apple orange pear
do
  echo "I really like ${fruit}s"
done
echo "Let's make a salad!"
