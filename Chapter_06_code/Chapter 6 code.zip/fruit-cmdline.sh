#!/bin/bash
for fruit in $*
do
  echo "I really like ${fruit}s"
done
echo "Let's make a salad!"
