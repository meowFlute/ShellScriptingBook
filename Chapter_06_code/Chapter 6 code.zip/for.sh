#!/bin/bash

for fruit
do
  echo I really like $fruit
done
echo "Let's make a salad!"
