#!/bin/bash

do_i_like()
{
  for fruit
  do
    echo I really like $fruit
  done
}

do_i_like apples bananas oranges
do_i_like satsumas apricots cherries

echo "Let's make a salad!"
