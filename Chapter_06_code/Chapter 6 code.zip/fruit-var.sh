#!/bin/bash
fruits="apple orange pear"
for fruit in $fruits
do
  echo "I really like ${fruit}s"
done
echo "Let's make a salad!"
