#!/bin/bash
for i in $*
do
  echo "I was passed $i"
done
