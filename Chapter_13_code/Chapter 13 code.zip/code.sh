#!/bin/bash
# this script is a useful script which does far
# more than its comments
# might suggest at first glance.
#
# for one thing, it demonstrates the valid use of comments in a shell script in a useful and practical manner.
# for another, it is very short and concise, unlike these comments, which are really rather rambling at best.
# so it is useful
# to have a script
# like this in your arsenal.

echo "$@"
# That was fun.
# The end.
# fin
